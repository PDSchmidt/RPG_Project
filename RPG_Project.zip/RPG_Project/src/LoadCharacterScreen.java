import java.util.*;
import javax.swing.*;
import java.awt.*;
public class LoadCharacterScreen extends Screen{
    public LoadCharacterScreen(String type,Container container, GameManager game) {
        super(type,container, game);
    }
}
