public class PlayerCharacter extends GameCharacter{
    //The vast nothingness will consume us all. Just as this class is empty,
    //we ourselves share the same burden of existential dread.

}
